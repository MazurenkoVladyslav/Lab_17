function populateCities() {
    var countrySelect = document.getElementById("country");
    var citySelect = document.getElementById("cities");
    var selectedCountry = countrySelect.value;
    citySelect.innerHTML = ""; 

    if (selectedCountry === "Germany") {
        addOption(citySelect, "Berlin/Берлін");
        addOption(citySelect, "Hamburg/Гамбург");
        addOption(citySelect, "Munich/Мюнхен");
    } else if (selectedCountry === "USA") {
        addOption(citySelect, "New York/Нью-Йорк");
        addOption(citySelect, "Los Angeles/Лос-Анджелес");
        addOption(citySelect, "Chicago/Чикаго");
    } else if (selectedCountry === "Ukraine") {
        addOption(citySelect, "Kyiv/Київ");
        addOption(citySelect, "Ternopil/Тернопіль");
        addOption(citySelect, "Lviv/Львів");
    }

    updateSelectedInfo(countrySelect.options[countrySelect.selectedIndex].text, citySelect.options[citySelect.selectedIndex].text);
}

function addOption(selectElement, optionText) {
    var option = document.createElement("option");
    option.text = optionText;
    selectElement.add(option);
}

function updateSelectedInfo(country, city) {
    var infoElement = document.getElementById("selectedInfo");
    infoElement.textContent = "Обрана країна: " + country + "||" + "Столиця: " + city;
}
